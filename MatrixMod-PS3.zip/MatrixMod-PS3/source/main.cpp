// MatrixMod - library menu for PS3 (PSL1GHT homebrew)
// Reads its list from items.txt next to the app, draws a category menu and
// lets you browse it with the controller. Built on the official PSL1GHT
// rsxtest + debugfont samples.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>
#include <ppu-types.h>

#include <sys/process.h>
#include <io/pad.h>
#include <rsx/rsx.h>
#include <sysutil/sysutil.h>

#include "rsxutil.h"
#include "drawenv.h"

SYS_PROCESS_PARAM(1001, 0x100000);

#define APP_DIR    "/dev_hdd0/game/MTRX00001/USRDIR/"
#define ITEMS_FILE APP_DIR "items.txt"
#define MAX_ITEMS  512
#define NUM_CATS   6

struct Item {
	char cat[8];
	char title[64];
	char ver[16];
	char size[16];
	char desc[200];
};

static Item items[MAX_ITEMS];
static int  nItems = 0;
static int  view[MAX_ITEMS];
static int  nView = 0;

static const char *catKeys[NUM_CATS]  = { "all", "ar", "tr", "hb", "tool", "lib" };
static const char *catNames[NUM_CATS] = { "All", "Arabized", "Translated", "Homebrew", "Tools", "Libraries" };

static int  curCat = 0;
static int  sel = 0;
static int  top = 0;
static char status[160] = "";
static u32  running = 0;

extern "C" {
static void program_exit_callback()
{
	gcmSetWaitFlip(context);
	rsxFinish(context, 1);
}

static void sysutil_exit_callback(u64 st, u64 param, void *usrdata)
{
	switch (st) {
		case SYSUTIL_EXIT_GAME:
			running = 0;
			break;
		default:
			break;
	}
}
}

// ---------------------------------------------------------------------------
// items

static void addItem(const char *cat, const char *title, const char *ver, const char *size, const char *desc)
{
	if (nItems >= MAX_ITEMS) return;
	Item &it = items[nItems++];
	snprintf(it.cat, sizeof(it.cat), "%s", cat);
	snprintf(it.title, sizeof(it.title), "%s", title);
	snprintf(it.ver, sizeof(it.ver), "%s", ver);
	snprintf(it.size, sizeof(it.size), "%s", size);
	snprintf(it.desc, sizeof(it.desc), "%s", desc);
}

// Line format:  category|title|version|size|description
// category is one of: ar tr hb tool lib.  Lines starting with # are ignored.
static void loadItems()
{
	FILE *f = fopen(ITEMS_FILE, "r");
	if (f) {
		char line[512];
		while (fgets(line, sizeof(line), f)) {
			char *fields[5] = { 0, 0, 0, 0, 0 };
			int n = 0;
			char *p = line;

			size_t len = strlen(line);
			while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) line[--len] = 0;
			if (len == 0 || line[0] == '#') continue;

			fields[n++] = p;
			while (*p && n < 5) {
				if (*p == '|') {
					*p = 0;
					fields[n++] = p + 1;
				}
				p++;
			}
			if (n < 5) continue;
			addItem(fields[0], fields[1], fields[2], fields[3], fields[4]);
		}
		fclose(f);
	}

	if (nItems == 0) {
		addItem("ar",   "Sample Arabized Game",   "1.00", "1.2 GB", "Sample entry. Create items.txt in the app folder to list your own content.");
		addItem("tr",   "Sample Translated Game", "1.00", "900 MB", "Sample entry with Arabic subtitles.");
		addItem("hb",   "Sample Homebrew",        "1.0",  "40 MB",  "Sample homebrew application.");
		addItem("tool", "Sample Tool",            "1.0",  "5 MB",   "Sample utility.");
	}
}

static void buildView()
{
	nView = 0;
	for (int i = 0; i < nItems; i++) {
		if (curCat == 0 || strcmp(items[i].cat, catKeys[curCat]) == 0)
			view[nView++] = i;
	}
	if (sel >= nView) sel = nView > 0 ? nView - 1 : 0;
	if (sel < 0) sel = 0;
	top = 0;
}

static int countCat(int c)
{
	if (c == 0) return nItems;
	int n = 0;
	for (int i = 0; i < nItems; i++)
		if (strcmp(items[i].cat, catKeys[c]) == 0) n++;
	return n;
}

static const char *catLabel(const char *key)
{
	for (int i = 1; i < NUM_CATS; i++)
		if (strcmp(key, catKeys[i]) == 0) return catNames[i];
	return key;
}

// ---------------------------------------------------------------------------
// drawing

static void text(int x, int y, int scale, float r, float g, float b, const char *s)
{
	DebugFont::setScale(scale);
	DebugFont::setPosition(x, y);
	DebugFont::setColor(r, g, b, 1.0f);
	DebugFont::print(s);
}

static void clearScreen()
{
	u32 i;
	setDrawEnv();
	rsxSetClearColor(context, 0x000D0A14);
	rsxSetClearDepthStencil(context, 0xffffff00);
	rsxClearSurface(context, GCM_CLEAR_R | GCM_CLEAR_G | GCM_CLEAR_B | GCM_CLEAR_A | GCM_CLEAR_S | GCM_CLEAR_Z);
	rsxSetZMinMaxControl(context, GCM_FALSE, GCM_TRUE, GCM_FALSE);
	for (i = 0; i < 8; i++)
		rsxSetViewportClip(context, i, display_width, display_height);
}

static void drawUI()
{
	const float AR = 0.61f, AG = 0.42f, AB = 1.00f;   // accent
	const float FR = 0.93f, FG = 0.91f, FB = 0.96f;   // text
	const float MR = 0.60f, MG = 0.56f, MB = 0.70f;   // muted

	int s     = (display_height >= 1000) ? 3 : 2;      // body scale
	int ts    = s + 2;                                 // title scale
	int mx    = (int)(display_width * 0.06f);          // side margin
	int my    = (int)(display_height * 0.06f);         // top margin
	int lineH = 9 * s + 1;
	int rowH  = lineH + lineH / 2;
	char buf[256];

	// header
	text(mx, my, ts, AR, AG, AB, "MatrixMod");
	text(mx, my + (9 * ts + 1) + 6, s, MR, MG, MB, "Games & tools library");

	// category tabs
	int tabY = my + (9 * ts + 1) + 6 + lineH * 2;
	int x = mx;
	for (int c = 0; c < NUM_CATS; c++) {
		snprintf(buf, sizeof(buf), c == curCat ? "[%s %d]" : " %s %d ", catNames[c], countCat(c));
		if (c == curCat) text(x, tabY, s, AR, AG, AB, buf);
		else             text(x, tabY, s, MR, MG, MB, buf);
		x += (int)strlen(buf) * (8 * s + 1) + 8 * s;
	}

	// list
	int listY   = tabY + lineH * 2;
	int footerH = lineH * 5;
	int rows    = (display_height - my - listY - footerH) / rowH;
	if (rows < 3) rows = 3;

	if (sel < top) top = sel;
	if (sel >= top + rows) top = sel - rows + 1;

	int colVer = mx + (int)((display_width - 2 * mx) * 0.55f);
	int colSize = mx + (int)((display_width - 2 * mx) * 0.67f);
	int colCat = mx + (int)((display_width - 2 * mx) * 0.80f);

	if (nView == 0) {
		text(mx, listY, s, MR, MG, MB, "No items in this category.");
	}

	for (int r = 0; r < rows && top + r < nView; r++) {
		int idx = view[top + r];
		int y = listY + r * rowH;
		bool on = (top + r == sel);
		float cr = on ? AR : FR, cg = on ? AG : FG, cb = on ? AB : FB;

		snprintf(buf, sizeof(buf), "%s %.38s", on ? ">" : " ", items[idx].title);
		text(mx, y, s, cr, cg, cb, buf);
		snprintf(buf, sizeof(buf), "v%s", items[idx].ver);
		text(colVer, y, s, MR, MG, MB, buf);
		text(colSize, y, s, MR, MG, MB, items[idx].size);
		text(colCat, y, s, MR, MG, MB, catLabel(items[idx].cat));
	}

	// footer: description, status, controls
	int fy = display_height - my - footerH;
	if (nView > 0) {
		int maxChars = (display_width - 2 * mx) / (8 * s + 1);
		snprintf(buf, sizeof(buf), "%.*s", maxChars - 1, items[view[sel]].desc);
		text(mx, fy, s, FR, FG, FB, buf);
	}
	if (status[0]) text(mx, fy + lineH * 2, s, AR, AG, AB, status);
	text(mx, fy + lineH * 4, s, MR, MG, MB, "L1/R1 category   UP/DOWN select   X install   O exit");
}

// ---------------------------------------------------------------------------

int main(int argc, const char *argv[])
{
	padInfo padinfo;
	padData paddata;
	bool pUp = false, pDown = false, pL1 = false, pR1 = false, pX = false, pO = false;

	void *host_addr = memalign(HOST_ADDR_ALIGNMENT, HOSTBUFFER_SIZE);

	init_screen(host_addr, HOSTBUFFER_SIZE);
	ioPadInit(7);

	DebugFont::init();
	DebugFont::setScreenRes(display_width, display_height);
	DebugFont::setSafeArea(0, 0, 0, 0);

	atexit(program_exit_callback);
	sysUtilRegisterCallback(0, sysutil_exit_callback, NULL);

	loadItems();
	buildView();

	setDrawEnv();
	setRenderTarget(curr_fb);

	running = 1;
	while (running) {
		sysUtilCheckCallback();

		bool up = false, down = false, l1 = false, r1 = false, x = false, o = false;
		ioPadGetInfo(&padinfo);
		for (int i = 0; i < MAX_PADS; i++) {
			if (padinfo.status[i]) {
				ioPadGetData(i, &paddata);
				up   |= paddata.BTN_UP;
				down |= paddata.BTN_DOWN;
				l1   |= paddata.BTN_L1;
				r1   |= paddata.BTN_R1;
				x    |= paddata.BTN_CROSS;
				o    |= paddata.BTN_CIRCLE;
			}
		}

		if (up && !pUp)     { if (sel > 0) sel--; status[0] = 0; }
		if (down && !pDown) { if (sel < nView - 1) sel++; status[0] = 0; }
		if (l1 && !pL1)     { curCat = (curCat + NUM_CATS - 1) % NUM_CATS; sel = 0; buildView(); status[0] = 0; }
		if (r1 && !pR1)     { curCat = (curCat + 1) % NUM_CATS; sel = 0; buildView(); status[0] = 0; }
		if (x && !pX && nView > 0) {
			// Install hook: add your own logic here (copy files, launch a tool, etc.).
			snprintf(status, sizeof(status), "Selected: %.60s (no install action is set yet)", items[view[sel]].title);
		}
		if (o && !pO) running = 0;

		pUp = up; pDown = down; pL1 = l1; pR1 = r1; pX = x; pO = o;

		clearScreen();
		drawUI();
		flip();
	}

	DebugFont::shutdown();
	program_exit_callback();
	return 0;
}
